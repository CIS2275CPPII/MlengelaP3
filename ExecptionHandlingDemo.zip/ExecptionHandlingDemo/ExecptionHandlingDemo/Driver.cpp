/***************************************************************************
* Program: Exceptional Handling Demo
* Programmer: Daudi Mlengela(dmlengela@cnm.edu)
* Date: September 29th 2022
* Purpose: Handling Exceptions in C++
***************************************************************************/

#include <iostream>
#include <vector>
#include <stdexcept>
using namespace std;
#include "DivideByZeroException.h";

double quotient(int numerator, int denominator);

int main()
{
	cout << "\n\n This is a Demonstration of some Exception Handling in C++."<<endl;

	/*1. C++ anything goes exception

	int age{ 15 };
	cout << "\n Enter your age: ";
	cin >> age;
	try
	{
		if (age > 18)
		{
			cout << "Access granted - you are old enough." << endl;
		}
		else
		{
			throw age;
		}
	}
	catch (int myAge)
	{
		cout << "\n Sorry, come back in " << 18 - myAge << " years. You are not old enough." << endl;
	}
	
	
	2. Vector OutOfRange Exception
	int length{ 0 };
	cout << "\n Enter vector length  ";
	cin >> length;
	try
	{
		vector<int> vec(length);
		cout << "\n Vec size: " << vec.size();
		vec.at(8) = 12;
	}
	catch (out_of_range exc)
	{
		cout << "\n Out of range exception caught" << endl
			<< exc.what() << endl;
	}
	
	
	3. Division By Zero
	int number1{ 0 }, number2{ 0 };
	cout << "\n Enter two numbers, with a space between them:";

	while (cin >> number1 >> number2)
	{
		try
		{
			double result = quotient(number1, number2);
			cout << "The quotient is: " << result << endl;
			cout << "\n Enter two numbers, with a space between them:";
		}
		catch (DivideByZeroException exc)
		{
			cout << "\n exception occurred: " << exc.what() << endl;
		}

	}*/
	//4. Catch any Exception
	int newAge{ 18 };
	cout << "\n Please enter your age: ";
	cin >> newAge;
	try
	{
		if (newAge > 18) 
		{
			cout << "Access granted - you are old enough." << endl;
		}
	}
	catch (...)
	{
		throw 505;
	}
	
		
	return 0;
}

double quotient(int numerator, int denominator)
{
	if (denominator == 0)
	{
		throw DivideByZeroException();
	}
	return (static_cast<double>(numerator) / denominator);
}