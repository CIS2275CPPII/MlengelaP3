/***************************************************************************
* Program: Exceptional Handling Demo
* Programmer: Daudi Mlengela(dmlengela@cnm.edu)
* Date: September 29th 2022
* Purpose: Handling Exceptions in C++
***************************************************************************/

#ifndef _DIVIDE_BY_ZERO_H
#define DIVIDE_BY_ZERO_H

#include <stdexcept>
using namespace std;

class DivideByZeroException : public runtime_error
{
public:
	DivideByZeroException() : runtime_error("Attempted to divide by zero") {}
};

#endif

