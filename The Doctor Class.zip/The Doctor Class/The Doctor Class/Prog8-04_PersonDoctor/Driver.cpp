// File:  Driver.cpp

#include "Doctor.h"

#include <iostream>
#include <string>

using namespace std;

int main()
{
	cout << "Constructors and Destructors ",
		

	cout << "\nKaren is our baby doctor."
		<<	"\nMake an object using default "
		<< "constructor, \nthen set the data.";

	Doctor BabyDoc;
	BabyDoc.SetData("Karen", 45, "Deliveries");

	BabyDoc.WriteDoctor();

	cout << "\n\nSean is our orthopedic surgeon."
		<< "\nMake an object the same way.";

	Doctor BoneGuy;
		
	BoneGuy.SetData("Sean", 38, "Orthopedics");

	BoneGuy.WriteDoctor();

	cout << "\nAll finished. End of program.\n";
	return 0;
}
