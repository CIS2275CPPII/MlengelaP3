// File:  Doctor.h

#ifndef _DOCTOR_H
#define _DOCTOR_H


#include <iostream>
#include <sstream>
using namespace std;

class Doctor
{
private:
	string name;
	int age{ 42 };
	string speciality;

public:
	Doctor();
	~Doctor();
	void SetData(string n, int a, string spec);
	string WriteDoctor();	
};

#endif