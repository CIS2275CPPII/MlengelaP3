// File:  Doctor.cpp

#include "Doctor.h"
#include <iostream>
using namespace std;

Doctor::Doctor() 
{
	cout << "\nIn the default Doctor constructor ";
	speciality = "";
}


void Doctor::SetData(string name, int age, string speciality)	
{
	this->name = name;
	this->age = age;
	this->speciality = speciality;
}

string Doctor::WriteDoctor()
{
	stringstream ss;
	ss<<"\n" << name << " is " << age <<" years old. ";
	ss<< "\nSpeciality:  " << speciality;
	return ss.str();
}

Doctor::~Doctor() 
{
	cout << "\nDestructing Doctor with a speciality of "
		<< speciality;
}

